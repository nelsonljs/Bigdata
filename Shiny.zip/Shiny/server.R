#install.packages('rsconnect')
#to deploy the app
#library(rsconnect)
#deployApp()
#terminateApp()

#setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
library(dplyr)
library(shiny)
library(shinyjs)
library(stringr)
library(DT)
library(visNetwork)

recipes_ingredients = read.csv('Recipe_Ingredients_Graph.csv', as.is = TRUE)
recipes_ingredients = recipes_ingredients %>%
  select(-X)

#We get the appropriate igraph
get_recipe_graph = function(Item1, Item2) {
  if (Item1 == "") {
    Item1 = "Orange Buns"
  }
  if (Item2 == "") {
    Item2 = "Dilly Bread"
  }
  mydf = recipes_ingredients %>%
    filter(Recipe %in% c(Item1, Item2))
  
  myvect = as.vector(t(as.matrix(mydf)))
  mynodes = data.frame(id = 1:length(unique(myvect)),
                       label = unique(myvect))
  mynodes$label = as.character(mynodes$label)
  nodes = mynodes %>%
    mutate(group = case_when(label %in% mydf$Recipe ~ "Recipe",
                             TRUE ~ "Ingredient")) %>%
    mutate(value = case_when(group == "Recipe" ~ 2,
                             TRUE ~ 1),
           shape = case_when(group == "Recipe" ~ "square",
                             TRUE ~ "circle"),
           title = label,
           color = case_when(group == "Recipe" ~ "darkblue",
                             TRUE ~ "yellow"),
           shadow = case_when(group == "Recipe" ~ TRUE,
                              TRUE ~ FALSE))
  
  mydf2 = left_join(mydf, mynodes, by = c("Recipe" = "label"))
  mydf2 = left_join(mydf2, mynodes, by = c("Ingredients" = "label"))
  edges = mydf2 %>%
    select(id.x, id.y) %>%
    `colnames<-`(c("from","to"))
  results = list()
  results$nodes = nodes
  results$edges = edges
  return(results)
}

get_ingredient_graph = function(Item1, Item2) {
  if (Item1 == "") {
    Item1 = "all-purpose flour"
  }
  if (Item2 == "") {
    Item2 = "egg"
  }
  mydf = recipes_ingredients %>%
    filter(Ingredients %in% c(Item1, Item2))
  mydf %>% 
    group_by(Recipe) %>% 
    summarize(count = n()) %>% 
    filter(count >1) %>% 
    pull(Recipe) -> myRecipes
  mydf = mydf %>%
    filter(Recipe %in% myRecipes)
  
  myvect = as.vector(t(as.matrix(mydf)))
  mynodes = data.frame(id = 1:length(unique(myvect)),
                       label = unique(myvect))
  mynodes$label = as.character(mynodes$label)
  nodes = mynodes %>%
    mutate(group = case_when(label %in% mydf$Recipe ~ "Recipe",
                             TRUE ~ "Ingredient")) %>%
    mutate(value = case_when(group == "Recipe" ~ 2,
                             TRUE ~ 1),
           shape = case_when(group == "Recipe" ~ "square",
                             TRUE ~ "circle"),
           title = label,
           color = case_when(group == "Recipe" ~ "darkblue",
                             TRUE ~ "yellow"),
           shadow = case_when(group == "Recipe" ~ TRUE,
                              TRUE ~ FALSE))
  
  mydf2 = left_join(mydf, mynodes, by = c("Recipe" = "label"))
  mydf2 = left_join(mydf2, mynodes, by = c("Ingredients" = "label"))
  edges = mydf2 %>%
    select(id.x, id.y) %>%
    `colnames<-`(c("from","to"))
  results = list()
  results$nodes = nodes
  results$edges = edges
  return(results)
}
function(input, output, session) {
  rvs = reactiveValues(recipes = NULL,
                       ingredients = NULL,
                       nodes = data.frame(id = 1:3),
                       edges = data.frame(from = c(1,2), to = c(1,3)))
######
# When the Apply button is clicked, Compute the graph
  observeEvent(input$RecipeGraph, {
    # output$myquery = renderText(paste("SELECT * FROM hivetable WHERE",
    #                        "MIN RATING >", input$MinRecipeRating, ",",
    #                        "MIN RATING COUNT >", input$MinRatingCount, ",",
    #                        "ISVEGAN is", input$isVegan))
  })
  
  observeEvent(input$IngredientGraph, {
    a = get_ingredient_graph(input$Ingredient1, input$Ingredient2)
    rvs$nodes <<- a$nodes
    rvs$edges <<- a$edges
  })
  
  #when the Reset button is clicked, remove all input values
  observeEvent(input$Reset, {
    shinyjs::reset("selection-panel")
    rvs$graph = graph(edges=c(1,2, 2,3, 3, 1), n=3, directed=F)
  })

  output$mygraph = renderVisNetwork({
    visNetwork(rvs$nodes, rvs$edges, height = "1000px", width = "100%")
  })
  output$myquery = renderText(paste("SELECT * FROM hivetable WHERE",
                                    "MIN RATING >", input$MinRecipeRating, ",",
                                    "MIN RATING COUNT >", input$MinRatingCount, ",",
                                    "ISVEGAN is", input$isVegan, ",",
                                    "ISNUTS is", !input$isNuts, ",",
                                    "ISSEAFOOD is", !input$isSeafood, ",",
                                    "ISBAKE is", !input$isBake, ",",
                                    "ISDEEPFRY is", !input$isDeepfry, ","
                              ))
}
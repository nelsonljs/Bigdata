pacman::p_load(tidyverse, neo4r, igraph, visNetwork, arules, arulesViz)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
recipes_db = read.csv("combined_label.csv", header = TRUE, stringsAsFactors = FALSE)
recipes_db = recipes_db %>%
  mutate(photo_url = case_when(photo_url == "" ~ "https://sciences.ucf.edu/psychology/wp-content/uploads/sites/63/2019/09/No-Image-Available.png",
                               TRUE ~ photo_url))


RIgraph = read.csv("RIgraph.csv", header = TRUE, stringsAsFactors = FALSE) # this is the Recipes Ingredient csv.
#### Start Market basket analysis
# Require a csv of items bought(ingredients used), each row is a transaction (recipe)
mybaskets = tapply(RIgraph$Ingredient,RIgraph$Recipe,list)
tr = as(mybaskets, "transactions")

tr
summary(tr)

# Subsetting transactions
a = subset(tr, items %ain% c("mint", "coriander"))
a
inspect(head(a,5))
##

itemFrequencyPlot(tr, topN=20, type='absolute')

rules <- apriori(tr, parameter = list(supp=0.001, conf=0.2, maxlen = 2))
rules <- sort(rules, by='lift', decreasing = TRUE)
summary(rules)
inspect(rules[1:10])

topRules <- rules[1:10]
plot(topRules)
plot(topRules, method="graph")

# Subsetting rules
rules.subset2 <- subset(rules, lhs %ain% c("cinnamon") & lift > 5)
rules.subset2 <- sort(rules.subset2, by='lift', decreasing = TRUE)
plot(rules.subset2, method="graph")
summary(rules.subset2)
inspect(head(rules.subset2,10))

# Subsetting transactions
a = subset(tr, items %ain% c("mint"))
a
inspect(head(a,5))
recipelist = a@itemsetInfo[["transactionID"]] # get character vector of recipes
##

## Inspecting the recipes with the associated ingredients.
inspect(head(subset(tr, items %ain% c("mint")),5))
#####

#########
# Using visNetwork
#########

#nodes is a dataframe with columns: id, label, group, value (size), shape, title, color, shadow
# mynodes = data.frame(id = 1:length(unique(myvect)),
#                    label = unique(myvect))
# nodes = nodes %>%
#   mutate(group = case_when(label %in% mydf$Recipe ~ "Recipe",
#                            TRUE ~ "Ingredient")) %>%
#   mutate(value = case_when(group == "Recipe" ~ 2,
#                            TRUE ~ 1),
#          shape = case_when(group == "Recipe" ~ "square",
#                            TRUE ~ "circle"),
#          title = label,
#          color = case_when(group == "Recipe" ~ "darkblue",
#                            TRUE ~ "yellow"),
#          shadow = case_when(group == "Recipe" ~ TRUE,
#                             TRUE ~ FALSE))
# 
# mydf2 = left_join(mydf, mynodes, by = c("Recipe" = "label"))
# mydf2 = left_join(mydf2, mynodes, by = c("Ingredient" = "label"))
# edges = mydf2 %>%
#   select(id.x, id.y) %>%
#   `colnames<-`(c("from","to"))
# 
# visNetwork(nodes, edges, height = "1000px", width = "100%")

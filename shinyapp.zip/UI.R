library(dplyr)
library(shiny)
library(shinythemes)
library(shinyjs)
library(shinycssloaders)
library(DT)
library(visNetwork)

recipes_ingredients = read.csv('filtered_list.csv', as.is = TRUE)
RecipeList = unique(recipes_ingredients["Recipe"]) %>%
  pull(Recipe)


fluidPage(theme = "bootstrap.css",
  
  titlePanel("Recipes Recommender"),
  br(),

  fluidRow(
    useShinyjs(),
    inlineCSS(list("table" = "font-size: 12px")),
    id = "selection-panel",
    column(6,
           fluidRow(
           column(6,
                  #this is the top left panel
                    div(style = "font-size:20px",
                        HTML("<b>Recipe Properties</b>")),
                    column(6,
                           br(),
                           br(),
                           
                      radioButtons(inputId = 'MinRecipeRating', 
                                  label = div(
                                    style = "font-size:12px",
                                    HTML('Minimum Recipe Rating')),
                                  choices = c(1,2,3,4),
                                  selected = 3,
                                  inline = TRUE,
                                  width = '100%'),
                      br(),
                      
                      radioButtons(inputId = 'MinRatingCount', 
                                   label = div(
                                     style = "font-size:12px",
                                     HTML('Minimum Rating Count')),
                                   choices = c(0,20,50,100),
                                   selected = 50,
                                   inline = TRUE)),
                    column(6,
                           sliderInput(inputId = 'ServesPax',
                                       label = div(
                                         style = "font-size:12px",
                                         HTML('Serves how many people')),
                                       min = 2,
                                       max = 8,
                                       value = 8,
                                       step = 2),
                           sliderInput(inputId = 'Calories',
                                       label = div(
                                         style = "font-size:12px",
                                         HTML('Calories per Serving')),
                                       min = 400,
                                       max = 2000,
                                       value = 2000,
                                       step = 200)
                           )
           ),
           column(6,
                  #this is the top middle panel
                  wellPanel(
                    h4(print("Ingredients you have in your fridge."))
                  )
           )),
           fluidRow(column(12,
             #this is the middle row with radio buttons
             div(style = "font-size:20px",
                 HTML("<b>Recipe Tags</b>")),
               column(2,
                      tags$div(class = 'custom-switch',
                               tags$input(type = 'checkbox',
                                          class ="custom-control-input",
                                          id = 'isVegan'),
                               tags$label(class = "custom-control-label",
                                          style = "font-size:12px",
                                          'for' = "isVegan",
                                          HTML('Vegetarian Only')))),
               
               column(2,
                      tags$div(class = 'custom-switch',
                               tags$input(type = 'checkbox',
                                          class ="custom-control-input",
                                          id = 'isNuts'),
                               tags$label(class = "custom-control-label",
                                          style = "font-size:12px",
                                          'for' = "isNuts",
                                          HTML('No Nut Allergen')))),
               column(2,
                      tags$div(class = 'custom-switch',
                               tags$input(type = 'checkbox',
                                          class ="custom-control-input",
                                          id = 'isSeafood'),
                               tags$label(class = "custom-control-label",
                                          style = "font-size:12px",
                                          'for' = "isSeafood",
                                          HTML('No seafood-allergens')))),
               
               column(3,
                      tags$div(class = 'custom-switch',
                               tags$input(type = 'checkbox',
                                          class ="custom-control-input",
                                          id = 'isBake'),
                               tags$label(class = "custom-control-label",
                                          style = "font-size:12px",
                                          'for' = "isBake",
                                          HTML('Exclude Baked Recipes')))),
               
               column(3,
                      tags$div(class = 'custom-switch',
                               tags$input(type = 'checkbox',
                                          class ="custom-control-input",
                                          id = 'isDeepfry'),
                               tags$label(class = "custom-control-label",
                                          style = "font-size:12px",
                                          'for' = "isDeepfry",
                                          HTML('Exclude Deep-fried Recipes'))))
               # tags$div(class = "form-group has-success",
               #          textInput(inputId = "textinput",
               #                    label = "Type Something"),
               #          div(class = "valid-feedback",
               #              HTML('yay!')))
             )
           ),
           fluidRow(
             column(12,
                    wellPanel(
                      h4(print("Pick 2 recipes to see their common ingredients!")),
                      wellPanel(
                        selectInput(inputId = 'Recipe1', 
                                    label = div(
                                      style = "font-size:12px",
                                      HTML('Recipe 1')),
                                    choices = c('', RecipeList),
                                    selected = 'Orange Buns'),
                        selectInput('Recipe2', 'Recipe 2', c('', RecipeList)))
                    ))
           ),
           fluidRow(
             column(12,
                    actionButton("RecipeButton", "Change Recipe", class = "btn btn-success"))),
           fluidRow(
             column(12,
               actionButton("IngredientButton", "Change Recipe"))),
           fluidRow(
             column(12,
               actionButton("Reset", "Reset Inputs")))
      ),
    column(6,
           h3(print("These are your Recommendations.")),
           tabsetPanel(type = "tabs",
                       tabPanel("First Recommendation",
                                br(),
                                fluidRow(
                                column(4,
                                       #Top left Panel
                                       # tags$ul(
                                       #   htmlOutput("ingredients1", container = tags$li, class = "custom-li-output")
                                       # )
                                       DT::dataTableOutput("recipe1")
                                ),
                                column(6,
                                       #top right panel
                                       htmlOutput("img1") %>% withSpinner((type = 1)))
                                ),
                                fluidRow(
                                  column(3,
                                         DT::dataTableOutput("ingredients1")),
                                  column(9,
                                         DT::dataTableOutput("instructions1"))
                                )),
                       tabPanel("My Hive Query",
                                verbatimTextOutput("myquery"),
                                verbatimTextOutput("test"))
           )
  ))
)

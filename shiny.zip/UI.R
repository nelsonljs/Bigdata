library(dplyr)
library(shiny)
library(shinythemes)
library(shinyjs)
library(shinycssloaders)
library(DT)

recipes_ingredients = read.csv('Recipe_Ingredients_Graph.csv', as.is = TRUE)
RecipeList = unique(recipes_ingredients["Recipe"]) %>%
  pull(Recipe)
IngredientList = unique(recipes_ingredients["Ingredients"]) %>%
  pull(Ingredients)

fluidPage(theme = shinytheme("slate"),
  
  titlePanel("Recipes Explorer"),

  fluidRow(
    useShinyjs(),
    id = "selection-panel",
    column(4,
           wellPanel(
             h4(print("Pick 2 recipes to see their common ingredients!")),
             wellPanel(
               selectInput('Recipe1', 'Recipe 1', c('', RecipeList)),
               selectInput('Recipe2', 'Recipe 2', c('', RecipeList)))
               ),
           wellPanel(
             h4(print("Pick 2 ingredients to see their common recipes!")),
             wellPanel(
               selectInput('Ingredient1', 'Ingredient 1', c('', IngredientList)),
               selectInput('Ingredient2', 'Ingredient 2', c('', IngredientList)))
           ),

           fluidRow(
             column(6,
                    actionButton("RecipeGraph", "Get Recipe Graph!"))),
           fluidRow(
             column(6,
                    actionButton("IngredientGraph", "Get Ingredient Graph!"))),
           fluidRow(
             column(6,
                    actionButton("Reset", "Reset inputs")))
      ),
    column(8,
           h3(print("This is your network graph.")),
           tabsetPanel(type = "tabs",
                       tabPanel("Recipe/Ingredient Graph",
                                h4(print("Graph (TEST)")),
                                plotOutput("mygraph") %>% withSpinner(type = 1))
           )
  ))
)

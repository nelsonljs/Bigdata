#install.packages('rsconnect')
#to deploy the app
#library(rsconnect)
#deployApp()
#terminateApp()

#setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
library(dplyr)
library(shiny)
library(shinyjs)
library(stringr)
library(DT)
library(igraph)

recipes_ingredients = read.csv('Recipe_Ingredients_Graph.csv', as.is = TRUE)
recipes_ingredients = recipes_ingredients %>%
  select(-X)

#We get the appropriate igraph
get_recipe_graph = function(Item1, Item2) {
  if (Item1 == "") {
    Item1 = "Orange Buns"
  }
  if (Item2 == "") {
    Item2 = "Dilly Bread"
  }
  mydf = recipes_ingredients %>%
    filter(Recipe %in% c(Item1, Item2))
  g2 = graph_from_data_frame(mydf, directed = FALSE)
  #coerce our graph
  myvertices = as_data_frame(g2, what = "vertices")
  myvertices = myvertices %>%
    mutate(type = case_when(name %in% mydf$Recipe ~ "Recipe",
                            TRUE ~ "Ingredient"))
  
  V(g2)$type = myvertices$type
  V(g2)$size <- ifelse(V(g2)$type == "Recipe", 40,15)
  V(g2)$color <- ifelse(V(g2)$type == "Recipe", "steel blue","yellow")
  V(g2)$shape <- ifelse(V(g2)$type == "Recipe", "square","circle")
  return(g2)
}

get_ingredient_graph = function(Item1, Item2) {
  if (Item1 == "") {
    Item1 = "all-purpose flour"
  }
  if (Item2 == "") {
    Item2 = "egg"
  }
  mydf = recipes_ingredients %>%
    filter(Ingredients %in% c(Item1, Item2))
  mydf %>% 
    group_by(Recipe) %>% 
    summarize(count = n()) %>% 
    filter(count >1) %>% 
    pull(Recipe) -> myRecipes
  mydf = mydf %>%
    filter(Recipe %in% myRecipes)
  
  g2 = graph_from_data_frame(mydf, directed = FALSE)
  #coerce our graph
  myvertices = as_data_frame(g2, what = "vertices")
  myvertices = myvertices %>%
    mutate(type = case_when(name %in% mydf$Recipe ~ "Recipe",
                            TRUE ~ "Ingredient"))
  
  V(g2)$type = myvertices$type
  V(g2)$size <- ifelse(V(g2)$type == "Recipe", 40,15)
  V(g2)$color <- ifelse(V(g2)$type == "Recipe", "steel blue","yellow")
  V(g2)$shape <- ifelse(V(g2)$type == "Recipe", "square","circle")
  return(g2)
}
function(input, output, session) {
  rvs = reactiveValues(recipes = NULL,
                       ingredients = NULL,
                       graph = graph(edges=c(1,2, 2,3, 3, 1), n=3, directed=F))
######
# When the Apply button is clicked, Compute the graph
  observeEvent(input$RecipeGraph, {
    rvs$graph <<- get_recipe_graph(input$Recipe1, input$Recipe2)
  })
  
  observeEvent(input$IngredientGraph, {
    rvs$graph <<- get_ingredient_graph(input$Ingredient1, input$Ingredient2)
  })
  
  #when the Reset button is clicked, remove all input values
  observeEvent(input$Reset, {
    shinyjs::reset("selection-panel")
    rvs$graph = graph(edges=c(1,2, 2,3, 3, 1), n=3, directed=F)
  })

  output$mygraph = renderPlot({
    plot(rvs$graph, edge.arrow.size=.5, vertex.label.color="black")
  })
}